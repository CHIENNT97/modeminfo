# luci-proto-fm350
The OpenWrt Luci protocol handler to configure Fibocom FM350 modems.

<details>
   <summary>Screenshots</summary>

   ![](https://raw.githubusercontent.com/koshev-msk/modemfeed/master/luci/protocols/luci-proto-fm350/screenshots/main.png)

   ![](https://raw.githubusercontent.com/koshev-msk/modemfeed/master/luci/protocols/luci-proto-fm350/screenshots/interfaces.png)

   ![](https://raw.githubusercontent.com/koshev-msk/modemfeed/master/luci/protocols/luci-proto-fm350/screenshots/setup.png)

</details>
