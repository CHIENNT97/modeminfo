# luci-proto-xmm
The OpenWrt Luci protocol handler to configure Intel cellular XMM modems.

<details>
   <summary>Screenshots</summary>

   ![](https://raw.githubusercontent.com/koshev-msk/modemfeed/master/luci/protocols/luci-proto-xmm/screenshots/main.png)

   ![](https://raw.githubusercontent.com/koshev-msk/modemfeed/master/luci/protocols/luci-proto-xmm/screenshots/interfaces.png)

   ![](https://raw.githubusercontent.com/koshev-msk/modemfeed/master/luci/protocols/luci-proto-xmm/screenshots/setup.png)

</details>
