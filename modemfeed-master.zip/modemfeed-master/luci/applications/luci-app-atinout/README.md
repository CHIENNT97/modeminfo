# luci-app-atinout

Web UI AT-commands using atinout for OpenWrt.

![](https://raw.githubusercontent.com/4IceG/Personal_data/master/atcommands.gif)
