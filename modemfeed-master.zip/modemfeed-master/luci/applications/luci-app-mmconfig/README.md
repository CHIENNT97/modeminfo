# luci-app-mmconfig
The OpenWrt Luci app configure modem cellular bands via mmcli utility

![](https://raw.githubusercontent.com/koshev-msk/modemfeed/master/luci/applications/luci-app-mmconfig/screenshot.png)
