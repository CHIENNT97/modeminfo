# luci-app-smstools3

Web UI smstools3 for OpenWrt LuCI.

Note: If you use this app with modemmanager, please move or remove /etc/hotplug.d/tty/25-modemmanager-tty

<details>
   <summary>Screenshots</summary>
   
   ![](https://raw.githubusercontent.com/koshev-msk/modemfeed/master/luci/applications/luci-app-smstools3/screenshots/incoming.png)
   
   ![](https://raw.githubusercontent.com/koshev-msk/modemfeed/master/luci/applications/luci-app-smstools3/screenshots/outcoming.png)
   
   ![](https://raw.githubusercontent.com/koshev-msk/modemfeed/master/luci/applications/luci-app-smstools3/screenshots/push.png)
   
   ![](https://raw.githubusercontent.com/koshev-msk/modemfeed/master/luci/applications/luci-app-smstools3/screenshots/setup.png)
   
</details>
