# luci-app-3proxy
Simple webUI OpenWrt Luci for 3proxy
