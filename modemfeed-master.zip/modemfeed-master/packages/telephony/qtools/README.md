# qtools OpenWrt package
Tools modems based on the Qualcomm chipset
