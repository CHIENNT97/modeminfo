# openwrt-accel-ppp
ACCEL-PPP is a high performance VPN server application for linux.
OpenWrt package
