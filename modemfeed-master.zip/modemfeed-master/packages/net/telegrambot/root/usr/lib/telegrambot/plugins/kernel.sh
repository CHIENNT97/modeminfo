#!/bin/sh
uname -a
