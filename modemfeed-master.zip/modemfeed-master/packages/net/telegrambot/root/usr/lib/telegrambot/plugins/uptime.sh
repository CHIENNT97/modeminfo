#!/bin/sh

uptime