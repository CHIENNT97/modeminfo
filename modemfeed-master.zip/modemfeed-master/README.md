# modemfeed

Vietnamese

# How-to add repo and compile packages

Add next line to feeds.conf.default in OpenWrt SDK/Buildroot

```
src-git modemfeed https://github.com/vietter99/modemfeed.git
```

# Precompiled packages

http://openwrt.132lan.ru/packages/21.02/packages/
